//
//  ViewController.swift
//  Match Two
//
//  Created by Aitzhan Ramazan on 25.04.2024.
//

import UIKit

class ViewController: UIViewController {
    var anotherButtonTag = 0
    var isOpened = false
    var counter = 0
    var setTimer = false
    var imageArray = [
        "Fast x", "Fast x",
        "Godzilla vs Kong", "Godzilla vs Kong",
        "knifes_out.png", "knifes_out.png",
        "Oppenheimer", "Oppenheimer",
        "potter", "potter",
        "Scream 6", "Scream 6",
        "shoushenk", "shoushenk",
        "Wednesday", "Wednesday"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func match_two(_ sender: UIButton) {
        if setTimer == true{
            return
        }
        if (sender.backgroundImage(for: .normal) != nil){
            return
        }
        sender.setBackgroundImage(UIImage(named: imageArray[sender.tag - 1]), for: .normal)
       
            if imageArray[sender.tag - 1] == imageArray[anotherButtonTag - 1] {
                counter += 1
            } else {
                setTimer = true
                
                Timer(timeInterval: 2, repeats: false) { _ in
                    sender.setBackgroundImage(nil, for: .normal)
                    
                    let anotherButton = self.view.viewWithTag(self.anotherButtonTag) as! UIButton
                    
                    anotherButton.setBackgroundImage(nil, for: .normal)
                    
                    self.setTimer = false
                }
                anotherButtonTag = sender.tag
            }
            isOpened.toggle()
            if counter == 8{
                alert()
            }
    }
    
    func alert() {
        let alert = UIAlertController(title: "You won", message: "Do you want to play again", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.clear()
        }))
        
        present(alert, animated: true, completion: nil)
    }
    
    
    
    
    func clear() {
        counter = 0
        for i in 0...16 {
            let button = view.viewWithTag(i + 1) as! UIButton
            button.setBackgroundImage(nil, for: .normal)
        }
    }
}

